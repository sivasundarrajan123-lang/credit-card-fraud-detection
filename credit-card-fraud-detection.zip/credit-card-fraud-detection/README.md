# 💳 Credit Card Fraud Detection using Machine Learning

A machine learning project to detect fraudulent credit card transactions using multiple classification algorithms.

## 📁 Project Structure

```
credit-card-fraud-detection/
│
├── cdd.csv                  # Dataset (credit card transactions)
├── modeltrain.ipynb         # Jupyter Notebook - full model training & EDA
├── app.py                   # Streamlit web app for fraud prediction
├── credit.py                # Model training script with visualizations
├── siva.py                  # Clean model training + CLI prediction
├── requirements.txt         # Python dependencies
└── README.md                # Project documentation
```

## 📊 Dataset

- **File:** `cdd.csv`
- **Features:** `Time`, `V1`–`V28` (PCA-transformed), `Amount`, `Class`
- **Target:** `Class` → `0` = Legitimate, `1` = Fraudulent

## 🤖 Models Used

| Model | Description |
|-------|-------------|
| Random Forest | Ensemble of decision trees |
| Logistic Regression | Linear classification |
| Support Vector Machine (SVM) | Margin-based classifier |
| K-Nearest Neighbors (KNN) | Distance-based classifier |
| Decision Tree | Rule-based classifier |

## 🚀 How to Run

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Streamlit Web App
```bash
streamlit run app.py
```

### 3. Run Model Training Script
```bash
python siva.py
```

### 4. Open Jupyter Notebook
```bash
jupyter notebook modeltrain.ipynb
```

## 📈 Results

- **Random Forest Accuracy:** ~97.5%
- Includes confusion matrix, classification report, and feature importance plots

## 🛠️ Tech Stack

- Python 3.x
- scikit-learn
- pandas, numpy
- matplotlib, seaborn
- Streamlit (web UI)
- imbalanced-learn (oversampling)

## 👤 Author

Your Name — [GitHub Profile](https://github.com/yourusername)
